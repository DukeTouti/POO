/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package khadija;

/**
 *
 * @author mehdi.najib
 */
public class Etd {
    
    // declaration des attributs 
    public int idEtd; 
    public String nomEtd; 
    private double moyenne;
    
    public static int nbrEtdPromo= 200; 
    
    
    public Etd(){
    
    }
    
    public Etd(int idEtd, String nomEtd, double moyenne ){
        this.idEtd = idEtd;
        this.nomEtd = nomEtd;
        this.moyenne = moyenne; 
    }
    
    public double getMoyenne(){
        return this.moyenne;
    }
    
    public void setMoyenne(double moyenne){
        this.moyenne = moyenne; 
    }
    
}
