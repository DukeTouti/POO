/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ma.ac.uir.exemplecourspoo1;

import java.util.Scanner;
import khadija.Etd;

/**
 *
 * @author mehdi.najib
 */
public class Test {
    
    public static void main(String[] args) {
           Scanner scN = new Scanner(System.in);
           Scanner scS = new Scanner(System.in);
           
           
           
           System.out.println("SVP votre age : ");
           int age = scN.nextInt();
           
           System.out.println("votre nom SVP");
          
           String nom = scS.nextLine();
           
           System.out.println("Votre age = " + age + " nom = " + nom);
           
           Etd etd1 = new Etd(1, "Khadija", 18.5);
           System.out.println(" nom = " + etd1.nomEtd);
           System.out.println("moyenne " + etd1.getMoyenne());
           
    }
}
